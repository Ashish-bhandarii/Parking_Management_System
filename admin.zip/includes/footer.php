<footer class="footer">
      <p style='color: white; text-align: center;'>&copy; 2025 ParkEase. All rights reserved.</p>
      <nav>
        <a href="../terms_of_service.php">Terms of Service</a>
        <a href="../privacy.php">Privacy</a>
      </nav>
    </footer>
</body>
</html>

